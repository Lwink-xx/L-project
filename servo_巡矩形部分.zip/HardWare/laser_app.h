#ifndef __LASER_APP_H
#define __LASER_APP_H

#include "bsp_system.h"

//打开激光
void Laser_ON(void);
//关闭激光
void Laser_OFF(void);

#endif
