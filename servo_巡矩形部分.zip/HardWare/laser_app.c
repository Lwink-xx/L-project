#include "laser_app.h"

/*
	laser --- 激光
	
	PB12 - 高电平触发
	
	红绿激光使用的板子不同，绿激光低电平触发，红激光高电平触发
*/

//打开激光
void Laser_ON(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
}

//关闭激光
void Laser_OFF(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
}
