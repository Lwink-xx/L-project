#ifndef __UART_APP_H
#define __UART_APP_H

#include "bsp_system.h"

void uart_task(void);
void uart3_task(void);

#endif
