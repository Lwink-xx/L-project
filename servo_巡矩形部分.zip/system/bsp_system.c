#include "bsp_system.h"

void servo_system_init(void)
{
	Step_Motor_X_Cmd();    //使能电机
	Step_Motor_Y_Cmd();	
	Step_Motor_X_Dir(1);   //控制方向  0 - 左转   1 - 右转
	Step_Motor_Y_Dir(1);   //  		   0 - 下转   1 - 上转
	
}


