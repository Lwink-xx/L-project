#ifndef __TASK_H
#define __TASK_H

#include "bsp_system.h"

void task_run(void);

#endif
