#include "uart_app.h"

uint8_t uart1_rx_dma_buf[128];
uint8_t uart3_rx_dma_buf[128];
uint8_t uart1_rx_buf[128];
uint8_t uart3_rx_buf[128];
bool uart1_rx_flag = false;
bool uart3_rx_flag = false;

int16_t X_Step;
int16_t Y_Step;


uint8_t i = 0;
int16_t Task1_step[5][2] = {0};   //X轴任务一点位

bool Task1_Start = false;
bool Task2_Start = false;
bool Task3_Start = false;
bool Task1_Plus = false;
bool Task2_Plus = false;
bool Task2_Plus_Stop = false;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(huart -> Instance == USART1)
	{
		for (uint8_t i = 0; i < Size; i++)
		{
			uart1_rx_buf[i] = uart1_rx_dma_buf[i];
		}
		uart1_rx_flag = true;
//		if(uart1_rx_dma_buf[0] == 'r' || uart1_rx_dma_buf[0] == 'R')   //如果接收到R，就停止当前任务，前往中点
//		{
//			Task1_Start = false;
//			Tripod_X_Abs_Step(Task1_step[4][0]);   //第五个点，记录中点
//			Tripod_Y_Abs_Step(Task1_step[4][1]);
//		}
		memset(uart1_rx_dma_buf, 0, sizeof(uart1_rx_dma_buf));  //清除缓存数据 --- 不能用 strlen
	}
	else if (huart -> Instance == USART3)
	{
		for (uint8_t i = 0; i < Size; i++)
		{
			uart3_rx_buf[i] = uart3_rx_dma_buf[i];
		}
		uart3_rx_flag = true;
		memset(uart3_rx_dma_buf, 0, sizeof(uart3_rx_dma_buf));  //清除缓存数据 --- 不能用 strlen
	}
}


void uart_task(void)
{
	if(uart1_rx_flag == false)
		return;

	
	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf));  //清除缓存数据
	uart1_rx_flag = false;
}


void uart3_task(void)
{
	if(uart3_rx_flag == false)
		return;
	
	if (uart3_rx_buf[0] == 'R' && uart3_rx_buf[1] == 'D')  //读取坐标
	{
		if (uart3_rx_buf[2] == 'x')
		{
			current_x = (uart3_rx_buf[3] - 48) * 100 + (uart3_rx_buf[4] - 48) * 10 + (uart3_rx_buf[5] - 48);	//获取当前X位置
		}
		if (uart3_rx_buf[6] == 'y')
		{
			current_y = (uart3_rx_buf[7] - 48) * 100 + (uart3_rx_buf[8] - 48) * 10 + (uart3_rx_buf[9] - 48);	//获取当Y前位置
		}
	}
	else if (uart3_rx_buf[0] == 'G' && uart3_rx_buf[1] == 'D')  //读取绿色激光目标位置
	{
		if (uart3_rx_buf[2] == 'x')
		{
			Red_x = (uart3_rx_buf[3] - 48) * 100 + (uart3_rx_buf[4] - 48) * 10 + (uart3_rx_buf[5] - 48);	//获取绿色激光X位置
		}
		if (uart3_rx_buf[6] == 'y')
		{
			Red_y = (uart3_rx_buf[7] - 48) * 100 + (uart3_rx_buf[8] - 48) * 10 + (uart3_rx_buf[9] - 48);	//获取绿色激光y位置
		}
	}
	else if (strncmp((const char*)uart3_rx_buf, "SLAVER", 6) == 0)	//发挥题 - 第一题
	{
		Task1_Plus = true;
	}
	
	else if (strncmp((const char*)uart3_rx_buf, "S3", 2) == 0)		//发挥题 - 第二题
	{
		Task2_Plus = true;
	}
	
	else if (strncmp((const char*)uart3_rx_buf, "STOP", 4) == 0)		//发挥题 - 第二题停止
	{
		Task2_Plus_Stop = true;
	}
	
	memset(uart3_rx_buf, 0, sizeof(uart3_rx_buf));  //清除缓存数据
	uart3_rx_flag = false;	
}

