#include "laser_app.h"

/*
	laser --- 激光
	
	PB12 - 低电平触发
*/

//打开激光
void Laser_ON(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
}

//关闭激光
void Laser_OFF(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
}
