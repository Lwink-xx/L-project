#include "main.h"
#include "math.h"
#include "rtthread.h"  // 确保有这一行

#define lineeeee 1
#define Expectspeed 410

/* MPU6050 相关变量 */
uint8_t ID;
uint8_t MPU6050_EXIT_Flag;

/* UART_1 字符串接收相关变量（K230） */
char UART_1_RxData;
#define UART_1_RX_STRING_MAX_LEN 50
char UART_1_RxString[UART_1_RX_STRING_MAX_LEN];
uint16_t UART_1_RxStringIndex = 0;
uint8_t UART_1_RxStringFlag = 0;

char oled_buf[20];

/* UART_2 字符串接收相关变量（蓝牙） */
char UART_2_RxData;
#define UART_2_RX_STRING_MAX_LEN 50
char UART_2_RxString[UART_2_RX_STRING_MAX_LEN];
uint16_t UART_2_RxStringIndex = 0;
uint8_t UART_2_RxStringFlag = 0;

/* 计时变量 */
int time_3000;
int time_1000;
int time_1500;

/* 遥控控制变量 */
int pattern   = lineeeee;
int line_ctrol = lineeeee;
int Task1_Plus = 5;

/* 电机输入预期控制相关变量 */
float Expect_line_error = -0.0f;
float Expect_Speed      = -0;
float Expect_TurnAngle  = 0;
float current_F         = 0;
int   current_Z         = 0;

/* 电机输出相关变量 */
int16_t Econder_Left, Econder_Right;
int Vertical_out;
int Velocity_out;
int Turn_out     = 0;
int PWM_out      = 0;
int LeftMotor_out, RightMotor_out;

float line_printf = 0;
float Pitch_xxx   = 0;

/* RT-Thread 信号量：MPU6050 数据就绪 */
static struct rt_semaphore mpu_sem;

/********************************************************************************************************************/
void OLED_Proc(void)
{
    OLED_ShowSignedNum(2, 8, imu_Angle.Pitch, 5);
    OLED_ShowSignedNum(3, 8, LeftMotor_out, 5);
    OLED_ShowSignedNum(4, 8, RightMotor_out, 5);
    OLED_ShowSignedNum(2, 1, Task1_Plus, 5);
    OLED_ShowSignedNum(3, 1, current_Z, 5);
    OLED_ShowSignedNum(4, 1, (int)Turn_out, 5);
}

/*******************************************************************************************************************/
/* 串口协议解析：在线程上下文里调用 */
void uart_task(void)
{
    if (UART_1_RxStringIndex > 0 && UART_1_RxString[UART_1_RxStringIndex - 1] == 'E')
    {
        if (UART_1_RxString[0] == '-')
        {
            if (UART_1_RxStringIndex == 5)
                current_Z = -((UART_1_RxString[1] - 48) * 100 + (UART_1_RxString[2] - 48) * 10 + (UART_1_RxString[3] - 48));
            if (UART_1_RxStringIndex == 4)
                current_Z = -((UART_1_RxString[1] - 48) * 10 + (UART_1_RxString[2] - 48));
            if (UART_1_RxStringIndex == 3)
                current_Z = -((UART_1_RxString[1] - 48));
        }
        else
        {
            current_Z = (UART_1_RxString[0] - 48) * 100 + (UART_1_RxString[1] - 48) * 10 + (UART_1_RxString[2] - 48);
        }
        current_F = (float)current_Z / 10.0f;
    }

    if (UART_2_RxStringIndex > 0 && UART_2_RxString[UART_2_RxStringIndex - 1] == '=')
    {
        if (UART_2_RxString[0] == 'U')      Task1_Plus = 1;
        else if (UART_2_RxString[0] == 'D') Task1_Plus = 2;
        else if (UART_2_RxString[0] == 'L') Task1_Plus = 3;
        else if (UART_2_RxString[0] == 'R') Task1_Plus = 4;
        else if (UART_2_RxString[0] == 'S') Task1_Plus = 5;
    }

    if (UART_2_RxStringIndex > 0 && UART_2_RxString[UART_2_RxStringIndex - 1] == '+')
    {
        if (UART_2_RxString[0] == 'M' && UART_2_RxString[1] == '1')       pattern = 0;
        else if (UART_2_RxString[0] == 'M' && UART_2_RxString[1] == '2')  pattern = 1;
        else if (UART_2_RxString[0] == 'O' && UART_2_RxString[1] == 'F')  line_ctrol = 0;
        else if (UART_2_RxString[0] == 'O' && UART_2_RxString[1] == 'N')  line_ctrol = 1;
    }
}

/* 平衡控制核心：保持原样，只去掉了串口打印 */
void balance_proc(void)
{
    Pitch_xxx     = (float)imu_Angle.Pitch;
    Econder_Left  = Encoder_Get();
    Econder_Right = Encoder1_Get();
    IMU_getEuleranAngles();

    if (pattern == 0)
    {
        switch (Task1_Plus)
        {
        case 1: Expect_Speed = 70;  Expect_TurnAngle = 0;   break;
        case 2: Expect_Speed = -70; Expect_TurnAngle = 0;   break;
        case 3: Expect_Speed = 0;   Expect_TurnAngle = -90; break;
        case 4: Expect_Speed = 0;   Expect_TurnAngle = 90;  break;
        case 5: Expect_Speed = 0;   Expect_TurnAngle = 0;   break;
        }
    }

    if (pattern == 1)
    {
        if (line_ctrol == 1) Expect_Speed = -Expectspeed;
        else                 Expect_Speed = 0;
    }

    Turn_out     = Turn(Expect_TurnAngle, imu_data.GZ, current_F, Expect_line_error,
                        (line_ctrol == 1 && pattern == 1));
    Vertical_out = Vertical(Expect_Angle, imu_Angle.Pitch, imu_data.GY);
    Velocity_out = Velocity(Expect_Speed, Econder_Left, Econder_Right);

    LeftMotor_out  = Vertical_out + Velocity_out - Turn_out;
    RightMotor_out = Vertical_out + Velocity_out + Turn_out;

    Motor_Limitation(&LeftMotor_out, &RightMotor_out);
    LeftMotor_Speed(LeftMotor_out);
    RightMotor_Speed(RightMotor_out);
}

/********************************************************************************************************************/
/* 平衡控制线程：最高优先级，由 MPU6050 中断信号量触发 */
void balance_thread_entry(void *parameter)
{
    while (1)
    {
        rt_sem_take(&mpu_sem, RT_WAITING_FOREVER);
        MPU6050_EXIT_Flag = 1;
        balance_proc();
    }
}

/* OLED 显示线程：低频刷新 */
void oled_thread_entry(void *parameter)
{
    while (1)
    {
        OLED_Proc();
        rt_thread_mdelay(100);
    }
}

/* 串口协议处理线程 */
void uart_thread_entry(void *parameter)
{
    while (1)
    {
        if (UART_1_RxStringFlag || UART_2_RxStringFlag)
        {
            uart_task();
            UART_1_RxStringFlag = 0;
            UART_2_RxStringFlag = 0;
            UART_1_RxStringIndex = 0;
            UART_2_RxStringIndex = 0;
        }
        rt_thread_mdelay(5);
    }
}

/********************************************************************************************************************/
/* USART1 中断：只收字节、置标志 */
void USART1_IRQHandler(void)
{
    rt_interrupt_enter();
    if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        UART_1_RxData = USART_ReceiveData(USART1);

        if (UART_1_RxStringIndex < UART_1_RX_STRING_MAX_LEN - 1)
        {
            UART_1_RxString[UART_1_RxStringIndex++] = UART_1_RxData;

            if (UART_1_RxString[UART_1_RxStringIndex - 1] == ')' ||
                UART_1_RxString[UART_1_RxStringIndex - 1] == '=' ||
                UART_1_RxString[UART_1_RxStringIndex - 1] == 'E')
            {
                UART_1_RxString[UART_1_RxStringIndex] = '\0';
                UART_1_RxStringFlag = 1;
            }
        }
        else
        {
            memset(UART_1_RxString, 0, UART_1_RX_STRING_MAX_LEN);
            UART_1_RxStringIndex = 0;
        }

        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
    rt_interrupt_leave();
}

/* USART2 中断：只收字节、置标志 */
void USART2_IRQHandler(void)
{
    rt_interrupt_enter();
    if (USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
    {
        UART_2_RxData = USART_ReceiveData(USART2);

        if (UART_2_RxStringIndex < UART_2_RX_STRING_MAX_LEN - 1)
        {
            UART_2_RxString[UART_2_RxStringIndex++] = UART_2_RxData;

            if (UART_2_RxString[UART_2_RxStringIndex - 1] == ')' ||
                UART_2_RxString[UART_2_RxStringIndex - 1] == '=' ||
                UART_2_RxString[UART_2_RxStringIndex - 1] == '+')
            {
                UART_2_RxString[UART_2_RxStringIndex] = '\0';
                UART_2_RxStringFlag = 1;
            }
        }
        else
        {
            memset(UART_2_RxString, 0, UART_2_RX_STRING_MAX_LEN);
            UART_2_RxStringIndex = 0;
        }

        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
    rt_interrupt_leave();
}

/********************************************************************************************************************/
/* MPU6050 EXTI0：发信号量唤醒平衡线程 */
void EXTI0_IRQHandler(void)
{
    rt_interrupt_enter();
    if (EXTI_GetITStatus(EXTI_Line0) == SET)
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
        {
            rt_sem_release(&mpu_sem);
        }
        EXTI_ClearITPendingBit(EXTI_Line0);
    }
    rt_interrupt_leave();
}

/********************************************************************************************************************/
int main(void)
{
    /* ---- 外设初始化（顺序与原工程一致）---- */
    OLED_Init();
    MPU6050_Init();
    MPU6050_EXIT_Init();
    PWM_Init();
    Motor_Init();
    Encoder_Init();
    Encoder1_Init();
    UART_1_Init();
    UART_2_Init();

    OLED_ShowString(1, 1, "ID:");
    ID = MPU6050_GetID();
    OLED_ShowHexNum(1, 4, ID, 2);
    UART_1_SendString("HelloUART1!");
    UART_2_SendString("HelloUART2!");

    /* ---- RT-Thread 内核对象 ---- */
    rt_sem_init(&mpu_sem, "mpu", 0, RT_IPC_FLAG_FIFO);

    /* ---- 创建线程 ---- */
    rt_thread_t tid;

    tid = rt_thread_create("balance", balance_thread_entry, RT_NULL,
                           2048, 5, 10);
    if (tid != RT_NULL) rt_thread_startup(tid);

    tid = rt_thread_create("oled", oled_thread_entry, RT_NULL,
                           1024, 20, 20);
    if (tid != RT_NULL) rt_thread_startup(tid);

    tid = rt_thread_create("uart", uart_thread_entry, RT_NULL,
                           2048, 15, 10);
    if (tid != RT_NULL) rt_thread_startup(tid);

    return 0;      		
}											
