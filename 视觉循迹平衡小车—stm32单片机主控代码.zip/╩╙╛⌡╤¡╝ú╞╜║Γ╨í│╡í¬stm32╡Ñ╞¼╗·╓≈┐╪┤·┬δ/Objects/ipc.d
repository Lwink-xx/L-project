.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\src\ipc.c
.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtthread.h
.\objects\ipc.o: .\User\rtconfig.h
.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdebug.h
.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdef.h
.\objects\ipc.o: E:\keil\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtservice.h
.\objects\ipc.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rthw.h
