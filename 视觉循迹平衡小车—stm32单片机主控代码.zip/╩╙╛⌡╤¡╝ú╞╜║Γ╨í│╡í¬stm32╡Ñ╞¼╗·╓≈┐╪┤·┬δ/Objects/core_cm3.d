.\objects\core_cm3.o: Start\core_cm3.c
.\objects\core_cm3.o: E:\keil\ARM\ARMCC\Bin\..\include\stdint.h
