.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\src\object.c
.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtthread.h
.\objects\object.o: .\User\rtconfig.h
.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdebug.h
.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdef.h
.\objects\object.o: E:\keil\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtservice.h
.\objects\object.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rthw.h
