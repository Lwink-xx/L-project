.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\src\components.c
.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rthw.h
.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtthread.h
.\objects\components.o: .\User\rtconfig.h
.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdebug.h
.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdef.h
.\objects\components.o: E:\keil\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\components.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtservice.h
