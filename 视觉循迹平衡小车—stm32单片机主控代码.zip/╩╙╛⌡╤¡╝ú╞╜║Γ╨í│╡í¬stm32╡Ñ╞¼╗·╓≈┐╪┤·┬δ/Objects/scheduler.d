.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\src\scheduler.c
.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtthread.h
.\objects\scheduler.o: .\User\rtconfig.h
.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdebug.h
.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdef.h
.\objects\scheduler.o: E:\keil\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtservice.h
.\objects\scheduler.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rthw.h
