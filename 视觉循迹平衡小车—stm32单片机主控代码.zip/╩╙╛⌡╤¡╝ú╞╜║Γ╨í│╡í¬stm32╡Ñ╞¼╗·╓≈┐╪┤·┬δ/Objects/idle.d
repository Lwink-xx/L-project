.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\src\idle.c
.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rthw.h
.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtthread.h
.\objects\idle.o: .\User\rtconfig.h
.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdebug.h
.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtdef.h
.\objects\idle.o: E:\keil\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\idle.o: E:\keil\ARM\PACK\RealThread\RT-Thread\3.1.5\include\rtservice.h
