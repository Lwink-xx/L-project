#ifndef __PID_H
#define __PID_H
#include "stm32f10x.h"                  // Device header

int Vertical(float Expect_Angle,float Current_Angle,float gyro_y);
int Velocity(float Expect_Seed,float Encoder_Left,float Encoder_Right);
int Turn(float Expect_Angle, float gyro_z, float line_error ,float Expect_line_error, int flag);  // 新增line_error参数
extern float Expect_Angle;

#endif
