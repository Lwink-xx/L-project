#include "PWM.h"                  // Device header
#include "IMU.h"
#include "Motor.h"

int PWM_MAX = 7200;
int PWM_MIN = -7200;

void Motor_Init(void)
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitTypeDef GPIO_InitSructure;
	GPIO_InitSructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitSructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitSructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitSructure);

	GPIO_InitSructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitSructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitSructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitSructure);

  PWM_Init();
}

void Motor_Limitation(int*LeftMotor,int*RightMotor)
{
if(*LeftMotor>PWM_MAX)//�����޷�
{
   *LeftMotor=PWM_MAX;
}
 if(*LeftMotor<PWM_MIN)
{
   *LeftMotor=PWM_MIN;
}
 if(*RightMotor>PWM_MAX)//�ҵ���޷�
{
   *RightMotor=PWM_MAX;
}
 if(*RightMotor<PWM_MIN)
{
   *RightMotor=PWM_MIN;
}
 if(imu_Angle.Pitch>=40||imu_Angle.Pitch<=-40)//��̬�������ƣ�ʹС��ֹͣ����
{
   *LeftMotor = 0;
   *RightMotor = 0;
}
}

void LeftMotor_Speed(int16_t Speed)//�����ٶȿ���//PA6����
{
	   if(Speed > 0 )
{
	GPIO_SetBits  (GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	PWM_SetCompare1(Speed);
}
else if(Speed == 0)
{
	GPIO_SetBits (GPIOA, GPIO_Pin_5);
	GPIO_SetBits (GPIOA, GPIO_Pin_4);
	PWM_SetCompare1(Speed);
}
else if(Speed < 0)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	GPIO_SetBits  (GPIOA,GPIO_Pin_4);
	PWM_SetCompare1(-Speed);
}
}

void RightMotor_Speed(int16_t Speed1)//�����ٶȿ���//PA7����
{
	if (Speed1 > 0)
	{
	GPIO_SetBits  (GPIOB,GPIO_Pin_14);
	GPIO_ResetBits(GPIOB,GPIO_Pin_15);
	PWM_SetCompare2(Speed1);
	}
else if(Speed1 == 0)
	{
	GPIO_SetBits (GPIOB,GPIO_Pin_14);
	GPIO_SetBits (GPIOB,GPIO_Pin_15);
	PWM_SetCompare2(Speed1);
	}
else if(Speed1 < 0)
  {
	GPIO_ResetBits(GPIOB,GPIO_Pin_14);
	GPIO_SetBits  (GPIOB,GPIO_Pin_15);
	PWM_SetCompare2(-Speed1);
  }
}


