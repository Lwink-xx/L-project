#include "stm32f10x.h"                  // Device header


////extern uint16_t Num;//extern,声明变量，告诉编译器，我们有这一个Num变量（不过是在别的文件里定义的，不过要让其自己去找）（在main函数定义的）
///**
//  * 函    数：定时中断初始化
//  * 参    数：无
//  * 返 回 值：无
//  */
//void Timer_Init(void)
//{
//	/*开启时钟*/
//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);			//开启TIM4的时钟
//	//注意要使用APB1开启该时钟函数，因为TIM2是APB1总线的外设
//	/*配置时钟源*/
//	TIM_InternalClockConfig(TIM4);		//选择TIM2为内部时钟，若不调用此函数，TIM默认也为内部时钟
//	//函数功能，使TIM2的 时基单元 变为由 内部时钟 来驱动的（保持代码完整性可以写上）
//	//上行代码不写也可以，因为定时器上电后默认就是使用内部时钟
//	/*时基单元初始化*/
//	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;				//定义结构体变量
//	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;		//时钟分频，选择不分频，此参数用于配置滤波器时钟，不影响时基单元功能
//	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	//计数器模式，选择向上计数
//	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;				//计数周期，即ARR的值
//	TIM_TimeBaseInitStructure.TIM_Prescaler = 720 - 1;				//预分频器，即PSC的值
//	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;			//重复计数器，高级定时器才会用到
//	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);				//将结构体变量交给TIM_TimeBaseInit，配置TIM2的时基单元
//	
//	/*中断输出配置*/      //该函数放在此处作用，防止上电的那一瞬间触发第一次中断
//	TIM_ClearFlag(TIM4, TIM_FLAG_Update);						//清除定时器更新标志位
//																//TIM_TimeBaseInit函数末尾，手动产生了更新事件
//																//若不清除此标志位，则开启中断后，会立刻进入一次中断
//																//如果不介意此问题，则不清除此标志位也可
//	
//	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);					//开启TIM2的更新中断，//更新中断
//	//使能 TIM_ITConfig （已经更新的）中断函数
//	/*NVIC中断分组*/
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);				//配置NVIC为分组2
//																//即抢占优先级范围：0~3，响应优先级范围：0~3
//																//此分组配置在整个工程中仅需调用一次
//																//若有多个中断，可以把此代码放在main函数内，while循环之前
//																//若调用多次配置分组的代码，则后执行的配置会覆盖先执行的配置
//	
//	/*NVIC配置*/
//	NVIC_InitTypeDef NVIC_InitStructure;						//定义结构体变量
//	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;				//选择配置NVIC的TIM2线
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//指定NVIC线路使能
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;	//指定NVIC线路的抢占优先级为2
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//指定NVIC线路的响应优先级为1
//	NVIC_Init(&NVIC_InitStructure);								//将结构体变量交给NVIC_Init，配置NVIC外设
//	
//	/*TIM使能*///最后一步用启动定时器函数 启动定时器
//	TIM_Cmd(TIM4, ENABLE);			//使能TIM2，定时器开始运行
//}
//    
///* 定时器中断函数，可以复制到使用它的地方//开始写中断函数
//void TIM4_IRQHandler(void)
//{
//	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)//获取中断函数标志位信息函数
//	{
//		
//		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);//清除中断函数标志位函数
//	}
//}
//*/
//void TIM4_IRQHandler(void)
//{
//	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)//获取中断函数标志位信息函数
//	{
//		if(LeftMotor_out>7200||LeftMotor_out<-7200||RightMotor_out>7200||RightMotor_out<-7200) ++times;
//		if(times == 1000) times = 0,flag_t = 1,LeftMotor_out = 0,RightMotor_out = 0;
//		else flag_t = 0;
//		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);//清除中断函数标志位函数
//	}
//}
