#ifndef __UART_1_H
#define __UART_1_H

#include <stdio.h>
#include "stm32f10x.h"                  // Device header

void UART_1_Init(void);
void UART_1_SendByte(uint8_t Byte);
void UART_1_SendArray(uint8_t *Array, uint16_t Length);
void UART_1_SendString(char *String);
void UART_1_SendNumber(uint32_t Number, uint8_t Length);
void UART_1_Printf(char *format, ...);

uint8_t UART_1_GetRxFlag(void);
uint8_t UART_1_GetRxData(void);

#endif
