#include "Encoder.h"
#include "IMU.h"
#include "MPU6050.h"
#include "Motor.h"
#include "PID.h"

//#define ver 1.0
#define ver 0.6

float Expect_Angle = 4.2f;                    //机械中值(需要自行测量)
#define vel 10.0       
#define vel005 0.005

float Vertical_Kp = -1750.0*ver;         //-(700)确定直立环Kp极性，使其倾倒方向与车轮旋转方向一致(跟随)//比例系数
float Vertical_Kd = -1750.0*ver;         //-2200直立环微分系数

//速度环
//float Velocity_Kp = 20;              //20(2000)确定速度环Kp的极性，使小车的速度快速达到最大值（如果极性错误，则车轮有阻力，而其两个车轮转向方向相反）
//float Velocity_Ki = 20*0.005;        // (1.0)速度环积分系数

float Velocity_Kp = vel/10.0;               //20(2000)确定速度环Kp的极性，使小车的速度快速达到最大值（如果极性错误，则车轮有阻力，而其两个车轮转向方向相反）
float Velocity_Ki = vel*vel005/10.0;         // (1.0)速度环积分系数

//转向环
float Turn_Kd = 0;                    //(1200)(同)确认Kd极性，转动车轮方向，如果极性正确则转动车轮时有很大的阻力//微分系数//转动速度
float Turn_Kp= 0;                         //转向期待速度
extern float Turn_Kp;                  //期待速度

// 巡线相关参
float Track_Kp = 140.0f;                 // 巡线比例系数（需根据实际调试调整）
float Track_Kd = 0.0f;                 // 巡线微分系数（抑制震荡）
float last_line_error = 0.0f;          // 上一次的巡线误差（用于微分计算）

//直立环(PD)；kp*ek+kd*(ek-ek-1)
//使在预期的角度上直立

int Vertical(float Expect_Angle,float Current_Angle,float gyro_y)
{
	int PWM_out;
	PWM_out = Vertical_Kp*(Current_Angle - Expect_Angle )+ Vertical_Kd * gyro_y;
	return PWM_out;
}

//速度环(pi控制)；kp*ek+ki*ek——sum
//函数作用，使左右轮在预期速度上运用
int Velocity(float Expect_Seed,float Encoder_Left,float Encoder_Right)
{
static int Encoder_Err,Encoder_Err_lowout_last,Encoder_Err_lowout,Encoder_Sum,PWM_out;

  //一阶的速度滤波
	Encoder_Err = (Encoder_Left+Encoder_Right)-Expect_Seed;

  Encoder_Err*=0.3;
  Encoder_Err_lowout_last*=0.7;

	Encoder_Err_lowout=Encoder_Err+Encoder_Err_lowout_last;

	Encoder_Err_lowout_last=Encoder_Err_lowout;

  Encoder_Sum+=Encoder_Err_lowout;

//幅值限制
if(Encoder_Sum>8000)
{
  Encoder_Sum=8000;
}
if(Encoder_Sum<-8000)
{
  Encoder_Sum=-8000;
}
	PWM_out=Velocity_Kp*Encoder_Err_lowout+Velocity_Ki*Encoder_Sum;
	return PWM_out;
}
//转向环
//预期角速度，绕Y轴角速度(实际角速度)
// 转向环（整合巡线补偿）


// 巡线控制：根据line_error计算转向补偿量
int Track(float line_error,float Expect_line_error)
{
    int track_compensate;  // 巡线转向补偿量
    // 计算微分项（当前误差 - 上一次误差）
		float current_error = line_error - Expect_line_error;
		float diff_error = current_error - last_line_error;
    // 巡线PID输出（比例+微分）
    track_compensate = Track_Kp * current_error + Track_Kd * diff_error;
    // 更新上一次误差，用于下一次微分计算
    last_line_error = current_error;
    if(track_compensate > 1000) track_compensate = 1000;
    if(track_compensate < -1000) track_compensate = -1000;
    return (int)track_compensate;
}

int Turn(float Expect_Angle, float gyro_z, float line_error ,float Expect_line_error ,int flag)  // 新增line_error参数
{ 
    int turn_base;       // 原有转向基础量
    int PWM_out;
 
    // 原有转向逻辑（基于预期角度和陀螺仪）
	if(flag == 0)
	{
    if (Expect_Angle == 0)
    {
        turn_base = Turn_Kd * gyro_z;  // 无预期角度时，基于陀螺仪稳定方向
    }
    else
    { 
        turn_base = Turn_Kp * Expect_Angle;  // 有预期角度时，转向到目标角度
    } 
	}
    // 计算巡线补偿量
	if(flag==1) 
	{
	turn_base = Track(line_error,Expect_line_error);
	}
	PWM_out = turn_base;

  return PWM_out;
} 
  

