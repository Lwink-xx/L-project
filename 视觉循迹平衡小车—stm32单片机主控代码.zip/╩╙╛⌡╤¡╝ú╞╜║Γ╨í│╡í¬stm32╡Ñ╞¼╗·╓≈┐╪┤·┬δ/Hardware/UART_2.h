#ifndef __UART_2_H
#define __UART_2_H
#include "stm32f10x.h"                  // Device header
#include <stdio.h>

void UART_2_Init(void);
void UART_2_SendByte(uint8_t Byte);
void UART_2_SendString(char *String);
void UART_2_Printf(char *format, ...);


#define U 0x20
#define D 0x21
#define S 0x22
#define L 0x23
#define R  0x24


#endif
