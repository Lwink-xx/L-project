#ifndef __Motor_H
#define __Motor_H

#include "stm32f10x.h"                  // Device header

void Motor_Init(void);
void Motor_Limitation(int*LeftMotor,int*RightMotor);
void LeftMotor_Speed(int16_t Speed);
void RightMotor_Speed(int16_t Speed1);







#endif



