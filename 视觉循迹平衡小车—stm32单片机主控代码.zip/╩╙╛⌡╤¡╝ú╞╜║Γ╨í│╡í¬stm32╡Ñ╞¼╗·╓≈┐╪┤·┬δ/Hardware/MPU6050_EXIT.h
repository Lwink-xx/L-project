#ifndef __MPU6050_EXIT_H
#define __MPU6050_EXIT_H
#include "stm32f10x.h"                  // Device header




void MPU6050_EXIT_Init(void);
int16_t Encoder_Get(void);







#endif
