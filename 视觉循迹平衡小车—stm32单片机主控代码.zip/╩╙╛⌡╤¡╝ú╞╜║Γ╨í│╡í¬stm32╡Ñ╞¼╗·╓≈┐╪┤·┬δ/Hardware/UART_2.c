#include "UART_2.h"
#include <stdio.h>
#include <stdarg.h>

/**
  * 函    数：串口初始化
  * 参    数：无
  * 返 回 值：无
  */
void UART_2_Init(void)
{
	/*开启时钟*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);	//开启USART2的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,  ENABLE);	//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;								//TX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);									//将PA9引脚初始化为复用推挽输出
		
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;               //RX
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);									//将PA10引脚初始化为上拉输入
	
	/*USART初始化*/
	USART_InitTypeDef USART_InitStructure;									//定义结构体变量
	USART_InitStructure.USART_BaudRate = 9600;							//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//硬件流控制，不需要
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	                //模式，发送模式和接收模式均选择
	USART_InitStructure.USART_Parity = USART_Parity_No;		                          //奇偶校验，不需要
	USART_InitStructure.USART_StopBits = USART_StopBits_1;	                        //停止位，选择1位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;		                  //字长，选择8位
	USART_Init(USART2, &USART_InitStructure);				        //将结构体变量交给USART_Init，配置USART1
	
	/*中断输出配置*/
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);			    //开启串口接收数据的中断
	

	/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;					          //定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;		    //选择配置NVIC的USART1线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			    //指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =15;//指定NVIC线路的抢占优先级为1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		  //指定NVIC线路的响应优先级为1
	NVIC_Init(&NVIC_InitStructure);						              //将结构体变量交给NVIC_Init，配置NVIC外设
	
	/*USART使能*/
	USART_Cmd(USART2, ENABLE);								              //使能USART1，串口开始运行
}

/**
  * 函    数：使用printf需要重定向的底层函数
  * 参    数：保持原始格式即可，无需变动
  * 返 回 值：保持原始格式即可，无需变动
  */

/*发送字节函数*/
void UART_2_SendByte(uint8_t Byte)
{
	USART_SendData(USART2, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}


int fputc(int ch, FILE *f)
{
	UART_2_SendByte(ch);			//将printf的底层重定向到自己的发送字节函数
	return ch;
}

/**
  * 函    数：串口发送一个字符串
  * 参    数：String 要发送字符串的首地址
  * 返 回 值：无
  */
void UART_2_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)  //遍历字符数组（字符串），遇到字符串结束标志位后停止
	{
		UART_2_SendByte(String[i]);		      //依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：自己封装的prinf函数
  * 参    数：format 格式化字符串
  * 参    数：... 可变的参数列表
  * 返 回 值：无
  */
void UART_2_Printf(char *format, ...)
{
	char String[100];				        //定义字符数组
	va_list arg;					          //定义可变参数列表数据类型的变量arg
	va_start(arg, format);			    //从format开始，接收参数列表到arg变量
	vsprintf(String, format, arg);	//使用vsprintf打印格式化字符串和参数列表到字符数组中
	va_end(arg);					          //结束变量arg
	UART_2_SendString(String);	 	  //串口发送字符数组（字符串）
}



